my $b;
$b=$mw->Button(-text=>'hello',-command=>sub{print $OUT 'hello'});
$b->pack;
