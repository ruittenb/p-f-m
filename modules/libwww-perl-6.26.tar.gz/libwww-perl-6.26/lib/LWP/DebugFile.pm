package LWP::DebugFile;
$LWP::DebugFile::VERSION = '6.26';
# legacy stub

1;
